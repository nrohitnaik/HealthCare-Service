package com.health.care.management.constant;

public abstract class Constant {

    // TODO based on the number of the constants let the modularisation be implemented

    // MYSQL config
    public static final String SQL_URL = "sql.datasource.url";
    public static final String SQL_USERNAME = "sql.datasource.username";
    public static final String SQL_PASSWORD = "sql.datasource.password";
    public static final String SQL_DRIVER = "sql.datasource.driver";

    // SQL quires
    public static final String FETCH_PATIENT_DETAILS_BY_ID = "select * from patient where id = ?";

    public static final String UPDATE_PATIENT_INFO = "UPDATE patient SET first_name=?, last_name=?, address=?, phone_number=? WHERE contact_id=?";

    public static final String SAVE_PATIENT = "INSERT INTO patient (first_name, last_name, sex, date_of_birth, address, mobile_number, alergies)  VALUES (?, ?, 1, ?, ?, ?, ?)";
    // Application Constants

    // logger Constants
}
