/*
 * PatientService.java
 * SRH Hochschule Heidelberg
 * All rights reserverd 2016
*/
package com.health.care.management.service;

import com.health.care.management.domain.Patient;

public interface PatientService {

    String findPatient(long id);

    // add or update patient
    void saveOrupdatePatientInfo(Patient patient);

}
