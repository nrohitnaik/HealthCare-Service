package com.health.care.management;

import static com.health.care.management.constant.Constant.SQL_DRIVER;
import static com.health.care.management.constant.Constant.SQL_PASSWORD;
import static com.health.care.management.constant.Constant.SQL_URL;
import static com.health.care.management.constant.Constant.SQL_USERNAME;

import com.health.care.management.dao.PatientDAO;
import com.health.care.management.dao.impl.PatientDAOImpl;
import com.health.care.management.domain.Patient;

import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class HealthCareServiceApplication {


    // TODO this is written in a generic way to test the application. Once all the functionality is implemented
    // exceptions must be handled in the appropriate way and resource must be closed..


    public static void main(String[] args) throws Exception {
        Properties properties = new Properties();
        InputStream ioStream = HealthCareServiceApplication.class.getClassLoader().getResourceAsStream("application.properties");

        properties.load(ioStream);

	    DriverManagerDataSource dataSource = new DriverManagerDataSource();

        dataSource.setUrl(properties.getProperty(SQL_URL));
        dataSource.setUsername(properties.getProperty(SQL_USERNAME));
        dataSource.setPassword(properties.getProperty(SQL_PASSWORD));
        dataSource.setDriverClassName(properties.getProperty(SQL_DRIVER));
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        PatientDAO pDao = new PatientDAOImpl(jdbcTemplate);
        
        Patient patient = new Patient();

        patient.setFirstName("Sandeep");
        patient.setLastName("logan ");
        // patient.setSex('M');
        patient.setDob(new Date("2016/03/03"));
        patient.setAlergies("girls ");
        pDao.saveOrupdatePatientInfo(patient);
	}

}