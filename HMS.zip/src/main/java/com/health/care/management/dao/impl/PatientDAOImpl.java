package com.health.care.management.dao.impl;

import com.health.care.management.constant.Constant;
import com.health.care.management.dao.PatientDAO;
import com.health.care.management.domain.Patient;

import org.springframework.jdbc.core.JdbcTemplate;

public class PatientDAOImpl implements PatientDAO {

    private JdbcTemplate jdbcTemplate;

    
    

    public PatientDAOImpl(JdbcTemplate jdbcTemplate) {
        super();
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public Patient findPatientById(long id) {
        return null;
    }

    @Override
    public void saveOrupdatePatientInfo(Patient patient) {
        
        // save new patient details
        jdbcTemplate.update(Constant.SAVE_PATIENT,
                new Object[] { patient.getFirstName(), patient.getLastName(), patient.getDob(), patient.getAddress(),
                patient.getPhoneNumber(), patient.getAlergies() });

    }

}
