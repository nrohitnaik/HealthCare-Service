/*
 * PatientServiceImpl.java
 * SRH Hochschule Heidelberg
 * All rights reserverd 2016
*/
package com.health.care.management.service.impl;

import com.health.care.management.dao.PatientDAO;
import com.health.care.management.domain.Patient;
import com.health.care.management.service.PatientService;

import org.codehaus.jackson.map.ObjectMapper;

public class PatientServiceImpl implements PatientService {


    // Used for mapping of object
    private ObjectMapper objectMapper = new ObjectMapper();

    private PatientDAO patientDAO;


    @Override
    public String findPatient(long id) {
        return null;
    }

    @Override
    public void saveOrupdatePatientInfo(Patient patient) {
        patientDAO.saveOrupdatePatientInfo(patient);
    }


}
