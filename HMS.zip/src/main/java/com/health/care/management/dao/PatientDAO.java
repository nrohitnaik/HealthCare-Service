package com.health.care.management.dao;

import com.health.care.management.domain.Patient;

public interface PatientDAO {


    Patient findPatientById(long id);

    void saveOrupdatePatientInfo(Patient patient);

}
