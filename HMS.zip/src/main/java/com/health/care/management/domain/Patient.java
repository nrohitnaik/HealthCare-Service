/*
 * Patient.java
 * SRH Hochschule Heidelberg
 * All rights reserverd 2016
*/
package com.health.care.management.domain;

import java.io.Serializable;
import java.util.Date;

public class Patient implements Serializable {

    private static final long serialVersionUID = 7972836498160502304L;

    private long id;
    private String firstName;
    private String lastName;
    private String address;
    private char sex;
    private long phoneNumber;
    private Date dob;
    private String alergies;

    /**
     * @return the id
     */
    public long getId() {
        return this.id;
    }

    /**
     * @param id the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return this.address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the sex
     */
    public char getSex() {
        return this.sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(char sex) {
        this.sex = sex;
    }

    /**
     * @return the phoneNumber
     */
    public long getPhoneNumber() {
        return this.phoneNumber;
    }

    /**
     * @param phoneNumber the phoneNumber to set
     */
    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the dob
     */
    public Date getDob() {
        return this.dob;
    }

    /**
     * @param dob the dob to set
     */
    public void setDob(Date dob) {
        this.dob = dob;
    }

    /**
     * @return the alergies
     */
    public String getAlergies() {
        return this.alergies;
    }

    /**
     * @param alergies the alergies to set
     */
    public void setAlergies(String alergies) {
        this.alergies = alergies;
    }

    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return String.format("Patient [id=%s, firstName=%s, lastName=%s, address=%s, sex=%s, phoneNumber=%s, dob=%s, alergies=%s]", this.id, this.firstName, this.lastName,
                this.address, this.sex, this.phoneNumber, this.dob, this.alergies);
    }

}
