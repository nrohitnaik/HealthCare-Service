package com.health.care.management.controller;

import com.health.care.management.service.PatientService;
import com.health.care.management.service.impl.PatientServiceImpl;

import java.util.Scanner;

public class Hospital {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        PatientService patientService = new PatientServiceImpl();
        System.out.println();
        Scanner scanner = new Scanner(System.in);
        int patienID = scanner.nextInt();
        patientService.findPatient(patienID);
        scanner.close();
    }

}
